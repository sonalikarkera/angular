export class Logins {
        constructor(
          public id: number,
          public uname: string,
          public pswd: string,
          public alterEgo?: string
        ) {  }
      
      }
      
